package facadeImpl;

import beans.Coupon;
import daoImpl.CompaniesDAODBImpl;
import daoImpl.CouponsDAODBImpl;
import daoImpl.CustomersDAODBImpl;
import exceptions.MyCouponException;
import facade.ClientFacade;

import java.util.ArrayList;

public class SystemMaintenanceFacade extends ClientFacade {

    private static final String EMAIL = "SystemMaintenance@system.com";
    private static final String PASSWORD = "SystemMaintenance";

    @Override
    public boolean login(String email, String password) throws MyCouponException {
        if (EMAIL.equals(email) && (PASSWORD.equals(password))) {
            initSession();
            return true;
        }
        return false;
    }


    public void deleteExpiredCoupons() throws MyCouponException {
        ArrayList<Coupon> coupons = couponsDAO.getAllExpiredCoupons();
        for (Coupon coupon : coupons) {
            couponsDAO.deleteAllCouponsPurchasesById(coupon.getId());
            couponsDAO.deleteCoupon(coupon.getId());
        }

    }

    private void initSession() {

        this.companiesDAO = new CompaniesDAODBImpl();
        this.couponsDAO = new CouponsDAODBImpl();
        this.customersDAO = new CustomersDAODBImpl();


    }

}

