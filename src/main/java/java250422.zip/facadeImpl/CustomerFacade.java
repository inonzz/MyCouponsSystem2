package facadeImpl;

import beans.Category;
import beans.Coupon;
import beans.Customer;
import daoImpl.CompaniesDAODBImpl;
import daoImpl.CouponsDAODBImpl;
import daoImpl.CustomersDAODBImpl;
import exceptions.MyCouponException;
import facade.ClientFacade;
import helper.CustomerFacadeVerification;

import java.util.ArrayList;

public class CustomerFacade extends ClientFacade {
    private int customerId;
    private CustomerFacadeVerification customerFacadeVerification;

    public CustomerFacade() {
        customerId = -1;
        companiesDAO = new CompaniesDAODBImpl();
        couponsDAO = new CouponsDAODBImpl();
        customersDAO = new CustomersDAODBImpl();
    }

    @Override
    public boolean login(String email, String password) throws MyCouponException {
        boolean isSuccessfullLogin = false;
        if (customersDAO.isCustomerExist(email,password)) {
            isSuccessfullLogin = true;
            initSession(customersDAO.getOneCustomerId(email, password));

        }
        return isSuccessfullLogin;
    }

    public void purchaseCoupon(Coupon coupon) throws MyCouponException {


        customerFacadeVerification.purchaseCouponValidation(coupon);
        couponsDAO.addCouponPurchase(customerId,coupon.getId());
        //update coupon amount
        coupon.setAmount(coupon.getAmount()-1);
        try {
            couponsDAO.updateCoupon(coupon);
        } catch (MyCouponException e) {
            couponsDAO.deleteCouponPurchase(customerId,coupon.getId());
            throw new MyCouponException("Repository Error: Update coupon Failed after purchase.purchase rollback",e);
        }
    }

    public ArrayList<Coupon> getCustomerCoupons() throws MyCouponException {
        customerFacadeVerification.getCustomerCouponsValidation();
        return customersDAO.getOneCustomer(customerId).getCoupons();
    }

    public ArrayList<Coupon> getCustomerCoupons(Category category) throws MyCouponException {
        customerFacadeVerification.getCustomerCouponsValidation();
        ArrayList<Coupon> coupons = getCustomerCoupons();
        ArrayList<Coupon> CategorisedCoupons = new  ArrayList<Coupon>();
        for (Coupon coupon: coupons)
            if (coupon.getCategory().getId() ==  category.getId())
                CategorisedCoupons.add(coupon);

        return CategorisedCoupons;
    }

    public ArrayList<Coupon> getCustomerCoupons(double maxPrice) throws MyCouponException {
        customerFacadeVerification.getCustomerCouponsValidation();
        ArrayList<Coupon> coupons = getCustomerCoupons();
        ArrayList<Coupon> MaxPricesCoupons = new  ArrayList<Coupon>();
        for (Coupon coupon: coupons)
            if (coupon.getPrice() <=  maxPrice)
                MaxPricesCoupons.add(coupon);

        return MaxPricesCoupons;
    }
    public Customer getCustomerDetails() throws MyCouponException {
        customerFacadeVerification.getCustomerDetailsValidation();
        return customersDAO.getOneCustomer(customerId);
    }

    private void initSession(int customerId){
        this.customerId = customerId;
        this.customerFacadeVerification = new CustomerFacadeVerification(companiesDAO,couponsDAO,
                customersDAO,customerId,true);
    }


}
