package dao;

import beans.Company;
import exceptions.MyCouponException;
import java.util.ArrayList;

public interface CompaniesDAO {

    public boolean isCompanyExists(String email, String password) throws MyCouponException;

    public boolean isCompanyExistsByNameOrEmail(String name, String email) throws MyCouponException;

    public boolean isCompanyExistsByNameAndId(String name, int id) throws MyCouponException;

    public void addCompany(Company company) throws MyCouponException;

    public void updateCompany(Company company) throws MyCouponException;

    public void deleteCompany(int companyId) throws MyCouponException;

    public ArrayList<Company> getAllCompanies() throws MyCouponException;

    public Company getOneCompany(int companyId) throws MyCouponException;

    public int getOneCompanyId(String email,String password) throws MyCouponException;
}
