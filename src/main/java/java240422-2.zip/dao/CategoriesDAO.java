package dao;

import beans.Category;
import exceptions.MyCouponException;
import java.util.ArrayList;

public interface CategoriesDAO {

    public void addCategory(Category category) throws  MyCouponException;

    public ArrayList<Category> getAllCategories() throws  MyCouponException;

    public boolean IsCategoryExist(int categoryId) throws MyCouponException;
 }
