package apps;

import beans.Category;
import beans.Company;
import beans.Coupon;
import beans.Customer;
import dao.CategoriesDAO;
import dao.CompaniesDAO;
import dao.CouponsDAO;
import dao.CustomersDAO;
import daoImpl.CategoriesDAODBImpl;
import daoImpl.CompaniesDAODBImpl;
import daoImpl.CouponsDAODBImpl;
import daoImpl.CustomersDAODBImpl;
import db.ConnectionPool;
import db.DatabaseManager;
import exceptions.MyCouponException;

import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Test {
    private static final int MAX_COMPANIES = 3;

    public static void main(String[] args) {

        System.out.println("======start building the DB======");

        try {
            DatabaseManager.databaseStrategy();
            System.out.println("\n======1.Init Categories =======\n");
            initCategories();
            System.out.println("\n======2.Init Companies ======\n");
            initCompanies();
            System.out.println("\n======3.Init Coupons DAO ======\n");
            initCoupons();
            System.out.println("\n======4.Bind Coupons to Companies ======\n");
            bindCouponsToCompanies();
            System.out.println("\n======5.Init customers ======\n");
            initCustomers();
            System.out.println("\n======6.Purchase Coupons ByCustomers ======\n");
            purchaseCouponsByCustomers();
            testCompanies();

            System.out.println("\n======close resources======\n");

            // add here check on tables


            ConnectionPool.getInstance().closeAllConnections();

        } catch (Exception e) {
            System.out.println("Exception");
            e.printStackTrace();
        }


        System.out.println("END");

    }

    private static void testCompanies() throws Exception {
        CompaniesDAO companiesDAO = new CompaniesDAODBImpl();
        ArrayList<Company> companies = companiesDAO.getAllCompanies();
        Company company =    companies.get(0);

        System.out.println("Test update Company\n");
        String oldEmail = company.getEmail();
        String oldpass = company.getPassword();

        company.setEmail("inon@email.com");
        company.setPassword("0000");
        companiesDAO.updateCompany(company);
        System.out.println("in bean:"+ company);
        System.out.println("in DB:"+ companiesDAO.getAllCompanies().get(0));

        company.setEmail(oldEmail);
        company.setPassword(oldpass);
        companiesDAO.updateCompany(company);

        System.out.println("rollback in bean:"+ company);
        System.out.println("rollback in DB:"+ companiesDAO.getAllCompanies().get(0));

        //check that by deleting companies,we are deleting all the coupons and purchases

        Company companyTobeDeleted= companies.get(companies.size()-1);
        ArrayList<Coupon> companyTobeDeletedCoupons = companyTobeDeleted.getCoupons();

        System.out.println("Test Delete last  Company: \n" + companyTobeDeleted.getId());
       CouponsDAO couponsDAO = new CouponsDAODBImpl();
       for(Coupon coupon: companyTobeDeletedCoupons){
            System.out.println(coupon.getId()+" BD purchased:"+ couponsDAO.isCouponPurchased(coupon.getId()));;
       }


        companiesDAO.deleteCompany(companyTobeDeleted.getId());
        if(companiesDAO.isCompanyExists(companyTobeDeleted.getEmail(),companyTobeDeleted.getPassword())) {
           throw new Exception();
        }
        for (Coupon coupon: companyTobeDeletedCoupons){
                System.out.println(coupon.getId()+" AD purchased:"+ couponsDAO.isCouponPurchased(coupon.getId()));;
            }


        System.out.println("Test Delete last  Company ended");
    }

    private static void purchaseCouponsByCustomers() throws MyCouponException {
        // get coupons
        CouponsDAO couponsDAO = new CouponsDAODBImpl();
        ArrayList<Coupon> coupons = couponsDAO.getAllCoupons();

        //get customers
        CustomersDAO customersDAO = new CustomersDAODBImpl();
        ArrayList<Customer> customers = customersDAO.getAllCustomers();

        //bind coupons to customer( purchase)
        couponsDAO.addCouponPurchase(customers.get(0).getId(),coupons.get(0).getId());
        couponsDAO.addCouponPurchase(customers.get(0).getId(),coupons.get(1).getId());

        couponsDAO.addCouponPurchase(customers.get(1).getId(),coupons.get(2).getId());
        couponsDAO.addCouponPurchase(customers.get(1).getId(),coupons.get(3).getId());

        couponsDAO.addCouponPurchase(customers.get(2).getId(),coupons.get(4).getId());
        couponsDAO.addCouponPurchase(customers.get(2).getId(),coupons.get(5).getId());

        couponsDAO.addCouponPurchase(customers.get(3).getId(),coupons.get(6).getId());
        couponsDAO.addCouponPurchase(customers.get(3).getId(),coupons.get(7).getId());

        couponsDAO.addCouponPurchase(customers.get(4).getId(),coupons.get(8).getId());
        couponsDAO.addCouponPurchase(customers.get(4).getId(),coupons.get(9).getId());

        couponsDAO.addCouponPurchase(customers.get(5).getId(),coupons.get(10).getId());
        couponsDAO.addCouponPurchase(customers.get(5).getId(),coupons.get(11).getId());


        System.out.println("print Customers  DB");
        customersDAO.getAllCustomers().forEach(System.out::println);








    }

    private static void initCustomers() throws MyCouponException {
        //init companies beans
        List<Coupon> couponListCustomer1 = new ArrayList<>();
        List<Coupon> couponListCustomer2 = new ArrayList<>();
        List<Coupon> couponListCustomer3 = new ArrayList<>();
        List<Coupon> couponListCustomer4 = new ArrayList<>();
        List<Coupon> couponListCustomer5 = new ArrayList<>();
        List<Coupon> couponListCustomer6 = new ArrayList<>();

        Customer customer1 = new Customer("CustName1","CustLast1","Customer1@gmail.com",
                "1234", (ArrayList<Coupon>) couponListCustomer1);
        Customer customer2 = new Customer("CustName2","CustLast2","Customer2@gmail.com",
                "5678", (ArrayList<Coupon>) couponListCustomer2);
        Customer customer3 = new Customer("CustName3","CustLast3","Customer3@gmail.com",
                "9012", (ArrayList<Coupon>) couponListCustomer3);
        Customer customer4 = new Customer("CustName4","CustLast4","Customer4@gmail.com",
                "3456", (ArrayList<Coupon>) couponListCustomer4);
        Customer customer5 = new Customer("CustName5","CustLast5","Customer5@gmail.com",
                "7890", (ArrayList<Coupon>) couponListCustomer5);
        Customer customer6 = new Customer("CustName6","CustLast6","Customer6@gmail.com",
                "1111", (ArrayList<Coupon>) couponListCustomer6);

        System.out.println("Customer1 bean" + customer1);
        System.out.println("Customer2 bean" + customer2);
        System.out.println("Customer3 bean" + customer3);
        System.out.println("Customer4 bean" + customer4);
        System.out.println("Customer5 bean" + customer5);
        System.out.println("Customer6 bean" + customer6);

        //add Customers  to DB
        CustomersDAO  customersDAO= new CustomersDAODBImpl();
        customersDAO.addCustomer(customer1);
        customersDAO.addCustomer(customer2);
        customersDAO.addCustomer(customer3);
        customersDAO.addCustomer(customer4);
        customersDAO.addCustomer(customer5);
        customersDAO.addCustomer(customer6);
        System.out.println("print Customers  DB");
        customersDAO.getAllCustomers().forEach(System.out::println);
    }

    private static void bindCouponsToCompanies() throws MyCouponException {
        //update coupons list to company
        System.out.println("print Companies DB after binding coupons");
        CompaniesDAO companiesDAO = new CompaniesDAODBImpl();
        companiesDAO.getAllCompanies().forEach(System.out::println);

    }

    private static void initCategories() throws Exception{

        CategoriesDAO categoriesDAO = new CategoriesDAODBImpl();
        categoriesDAO.addCategory(Category.FOOD);
        categoriesDAO.addCategory(Category.ELECTRICITY);
        categoriesDAO.addCategory(Category.RESTAURANT);
        categoriesDAO.addCategory(Category.VACATION);

        categoriesDAO.getAllCategories().forEach( category -> {
            System.out.print(category + " ");
        });
        System.out.println();
      }


    public static void initCompanies() throws Exception {



        //init companies beans
        List<Coupon> couponListCompany1 = new ArrayList<>();
        List<Coupon> couponListCompany2 = new ArrayList<>();
        List<Coupon> couponListCompany3 = new ArrayList<>();

        Company company1 = new Company("Company1","Company1@gmail.com","1234", (ArrayList<Coupon>) couponListCompany1);
        Company company2 = new Company("Company2","company2@gmail.com","5678", (ArrayList<Coupon>) couponListCompany2);
        Company company3 = new Company("Company3","company3@gmail.com","9012", (ArrayList<Coupon>) couponListCompany3);
        System.out.println("Company1 bean" + company1);
        System.out.println("Company2 bean" + company2);
        System.out.println("Company3 bean" + company3);

         //add Companies to DB
        CompaniesDAO companiesDAO = new CompaniesDAODBImpl();
        companiesDAO.addCompany(company1);
        companiesDAO.addCompany(company2);
        companiesDAO.addCompany(company3);
        System.out.println("print Companies DB");
        companiesDAO.getAllCompanies().forEach(System.out::println);
    }

    public static void initCoupons() throws Exception {
        //get Company ID
        CompaniesDAO companiesDAO = new CompaniesDAODBImpl();
        ArrayList<Company> allCompanies  = companiesDAO.getAllCompanies();
        if (allCompanies.size() < MAX_COMPANIES) {
            throw new Exception();
        }


        //init coupons  plus link to company

        Coupon coupon1Comp1 = new Coupon(allCompanies.get(0).getId(), Category.FOOD,"PizzaDalal","Good Pizza place",Date.valueOf("2022-04-25"),Date.valueOf("2022-04-26"),10,20,"*****" );
        Coupon coupon2Comp1 = new Coupon(allCompanies.get(0).getId(), Category.VACATION,"ScubaDalal","Scuba Dive",Date.valueOf("2022-04-25"),Date.valueOf("2022-04-26"),10,20,"*****" );

        Coupon coupon1Comp2 = new Coupon(allCompanies.get(1).getId(), Category.ELECTRICITY,"CompDalal","computer place",Date.valueOf("2022-04-25"),Date.valueOf("2022-04-26"),10,20,"****" );
        Coupon coupon2Comp2 = new Coupon(allCompanies.get(1).getId(), Category.RESTAURANT,"FalafelDalal","Falafel Fast food",Date.valueOf("2022-04-25"),Date.valueOf("2022-04-26"),10,20,"****" );

        Coupon coupon1Comp3 = new Coupon(allCompanies.get(2).getId(), Category.ELECTRICITY,"Salon  Dalal","Electricity  place",Date.valueOf("2022-04-25"),Date.valueOf("2022-04-26"),10,20,"***" );
        Coupon coupon2Comp3 = new Coupon(allCompanies.get(2).getId(), Category.VACATION," HOTEL Dalal","Hotel Place",Date.valueOf("2022-04-25"),Date.valueOf("2022-04-26"),10,20,"***" );

        Coupon coupon3Comp1 = new Coupon(allCompanies.get(0).getId(), Category.ELECTRICITY,"Salon  Dalal2","Electricity  place2",Date.valueOf("2022-04-25"),Date.valueOf("2022-04-26"),20,40,"**" );
        Coupon coupon4Comp1 = new Coupon(allCompanies.get(0).getId(), Category.VACATION," HOTEL Dalal2","Hotel Place2",Date.valueOf("2022-04-25"),Date.valueOf("2022-04-26"),20,40,"**" );

        Coupon coupon3Comp2 = new Coupon(allCompanies.get(1).getId(), Category.ELECTRICITY,"PizzaDalal2","Electricity  place2",Date.valueOf("2022-04-25"),Date.valueOf("2022-04-26"),20,40,"*" );
        Coupon coupon4Comp2 = new Coupon(allCompanies.get(1).getId(), Category.VACATION," ScubaDalal2","Hotel Place2",Date.valueOf("2022-04-25"),Date.valueOf("2022-04-26"),20,40,"*" );

        Coupon coupon3Comp3 = new Coupon(allCompanies.get(2).getId(), Category.ELECTRICITY,"CompDalal2","Electricity  place2",Date.valueOf("2022-04-25"),Date.valueOf("2022-04-26"),20,40,";" );
        Coupon coupon4Comp3 = new Coupon(allCompanies.get(2).getId(), Category.VACATION," FalafelDalal2","Hotel Place2",Date.valueOf("2022-04-25"),Date.valueOf("2022-04-26"),20,40,";" );


        System.out.println("print Coupons beans total 6");
        System.out.println("coupon1Comp1 bean" + coupon1Comp1);
        System.out.println("coupon2Comp1 bean" + coupon2Comp1);

        System.out.println("coupon1Comp2 bean" + coupon1Comp2);
        System.out.println("coupon2Comp2 bean" + coupon2Comp2);

        System.out.println("coupon1Comp3 bean" + coupon1Comp3);
        System.out.println("coupon2Comp3 bean" + coupon2Comp3);

        //add coupons to DB
        CouponsDAO couponsDAO = new CouponsDAODBImpl();
        couponsDAO.addCoupon(coupon1Comp1);
        couponsDAO.addCoupon(coupon2Comp1);

        couponsDAO.addCoupon(coupon1Comp2);
        couponsDAO.addCoupon(coupon2Comp2);

        couponsDAO.addCoupon(coupon1Comp3);
        couponsDAO.addCoupon(coupon2Comp3);

        couponsDAO.addCoupon(coupon3Comp1);
        couponsDAO.addCoupon(coupon4Comp1);

        couponsDAO.addCoupon(coupon3Comp2);
        couponsDAO.addCoupon(coupon4Comp2);

        couponsDAO.addCoupon(coupon3Comp3);
        couponsDAO.addCoupon(coupon4Comp3);

        System.out.println("print Coupons DB");
        couponsDAO.getAllCoupons().forEach(System.out::println);

        //TODO test other API :
//        couponsDAO.updateCoupon();
//        couponsDAO.getOneCoupon();
//        couponsDAO.addCoupon();
//        couponsDAO.deleteCouponPurchase();
//        couponsDAO.isCouponPurchased();
//        couponsDAO.isExist ???





    }

    public static void testCustomersDAO() {



    }
}
