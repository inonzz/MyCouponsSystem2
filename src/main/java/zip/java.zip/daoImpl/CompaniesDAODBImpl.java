package daoImpl;

import beans.Company;
import beans.Coupon;
import dao.CompaniesDAO;
import dao.CouponsDAO;
import db.ConnectionPool;
import db.JDBCUtils;
import db.ResultsUtils;
import exceptions.MyCouponException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CompaniesDAODBImpl implements CompaniesDAO {
    //MEMBERS
    private ConnectionPool connectionPool;
    //QUERIES
    private static final String QUERY_COMPANIES_INSERT = "INSERT INTO `coupons_system`.`companies` (`name`, `email`, `password`) VALUES (?, ?, ?);\n";

    private static final String QUERY_COMPANIES_UPDATE = "UPDATE `coupons_system`.`companies` SET `name` = ?, `email` = ?, `password` = ? WHERE (`id` = ?);\n";

    private static final String QUERY_COMPANIES_DELETE = "DELETE FROM `coupons_system`.`companies` WHERE (`id` = ?);";

    private static final String QUERY_COMPANIES_IS_EXIST_BY_EMAIL_AND_PASSWORD = "SELECT EXISTS(SELECT * FROM `coupons_system`.`companies` where (email=? and password=?) as res";

    private static final String QUERY_COMPANIES_IS_EXIST_BY_NAME_OR_EMAIL = "SELECT EXISTS(SELECT * FROM `coupons_system`.`companies` where (name=? or email=? ) as res";

    private static final String QUERY_COMPANIES_IS_EXIST_BY_NAME_AND_ID = "SELECT EXISTS(SELECT * FROM `coupons_system`.`companies` where (name=? and id=? ) as res";

    private static final String QUERY_ALL_COMPANIES = "SELECT * FROM `coupons_system`.`companies`;";

    private static final String QUERY_ALL_COMPANIES_IDS = "SELECT id FROM `coupons_system`.`companies`;";

    private static final String QUERY_COMPANIES_BY_ID = "SELECT * FROM `coupons_system`.`companies` where id=?";

    public boolean isCompanyExistsByNameOrEmail(String name, String Email) throws MyCouponException{
        boolean isExist = false;

        Map<Integer, Object> map = new HashMap<>();
        map.put(1, name);

        List<?> res = null;
        try {
            res = JDBCUtils.executeResults(QUERY_COMPANIES_IS_EXIST_BY_NAME_OR_EMAIL, map);
        } catch (Exception e) {
            throw new MyCouponException("Repository Error: Failed to isCompanyExistsByNameOrEmail",e);
        }
        for (Object row : res) {
            isExist = ResultsUtils.fromHashMapToBoolean((HashMap<Integer, Object>) row);
            break;
        }

        return isExist;


    }

    public boolean isCompanyExistsByNameAndId(String name, int id) throws MyCouponException{
        boolean isExist = false;

        Map<Integer, Object> map = new HashMap<>();
        map.put(1, name);

        List<?> res = null;
        try {
            res = JDBCUtils.executeResults(QUERY_COMPANIES_IS_EXIST_BY_NAME_AND_ID, map);
        } catch (Exception e) {
            throw new MyCouponException("Repository Error: Failed to isCompanyExistsByNameAndId",e);
        }
        for (Object row : res) {
            isExist = ResultsUtils.fromHashMapToBoolean((HashMap<Integer, Object>) row);
            break;
        }

        return isExist;
    }

    @Override
    public boolean isCompanyExists(String email, String password) throws MyCouponException {
        boolean isExist = false;

        Map<Integer, Object> map = new HashMap<>();
        map.put(1, email);
        map.put(2, password);


        List<?> res = null;
        try {
            res = JDBCUtils.executeResults(QUERY_COMPANIES_IS_EXIST_BY_EMAIL_AND_PASSWORD, map);
        } catch (Exception e) {
            throw new MyCouponException("Repository Error: Failed to isCompanyExists",e);
        }
        for (Object row : res) {
            isExist = ResultsUtils.fromHashMapToBoolean((HashMap<Integer, Object>) row);
            break;
        }

        return isExist;

    }

    @Override
    public void addCompany(Company company) throws MyCouponException {
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, company.getName());
        map.put(2, company.getEmail());
        map.put(3, company.getPassword());
        ArrayList<Coupon> coupons = company.getCoupons();

        try {
            JDBCUtils.execute(QUERY_COMPANIES_INSERT, map);
        } catch (Exception e) {
            throw new MyCouponException("Repository Error: Failed to addCompany",e);
        }

        CouponsDAO couponsDAO = new CouponsDAODBImpl();
        for (Coupon coupon : coupons) {
            try {
                couponsDAO.addCoupon(coupon);
            } catch (Exception e) {
                throw new MyCouponException("Repository Error: Failed to addCoupon in addCompany",e);
            }
        }
    }

    @Override
    public void updateCompany(Company company) throws MyCouponException {
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, company.getName());
        map.put(2, company.getEmail());
        map.put(3, company.getPassword());
        map.put(4, company.getId());
        ArrayList<Coupon> coupons = company.getCoupons();

        try {
            JDBCUtils.execute(QUERY_COMPANIES_UPDATE, map);
        } catch (Exception e) {
            throw new MyCouponException("Repository Error: Failed to updateCompany[1]",e);
        }
        CouponsDAO couponsDAO = new CouponsDAODBImpl();
        for (Coupon coupon : coupons) {
            try {
                couponsDAO.updateCoupon(coupon);
            } catch (Exception e) {
                throw new MyCouponException("Repository Error: Failed to updateCompany[2]",e);
            }
        }
    }

    @Override
    public void deleteCompany(int companyId) throws MyCouponException {
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, companyId);
        try {
            JDBCUtils.execute(QUERY_COMPANIES_DELETE, map);
        } catch (Exception e) {
            throw new MyCouponException("Repository Error: Failed to deleteCompany",e);
        }
    }

    @Override
    public ArrayList<Company> getAllCompanies() throws MyCouponException {
        ArrayList<Company> companies = new ArrayList<>();

        List<?> res = null;
        try {
            res = JDBCUtils.executeResults(QUERY_ALL_COMPANIES_IDS);
        } catch (Exception e) {
            throw new MyCouponException("Repository Error: Failed to getAllCompanies",e);
        }
        int companyId = 0;
        for (Object row : res) {
            companyId  = (int) ((HashMap<?, ?>) row).get("id");
            companies.add(getOneCompany(companyId));
        }
        return companies;
    }

    @Override
    public Company getOneCompany(int companyId) throws MyCouponException {
        Company company = null;

        Map<Integer, Object> map = new HashMap<>();
        map.put(1, companyId);
        List<?> resCompanyTable = null;
        try {
            resCompanyTable = JDBCUtils.executeResults(QUERY_COMPANIES_BY_ID, map);
        } catch (Exception e) {
            throw new MyCouponException("Repository Error: Failed to getOneCompany",e);
        }

        CouponsDAO couponsDAO = new CouponsDAODBImpl();

        for (Object rowCompnayTable : resCompanyTable) {
            try {
                company = ResultsUtils.fromHashMapToCompany((HashMap<Integer, Object>) rowCompnayTable,
                        couponsDAO.getAllCouponsByCompanyId(companyId));
            } catch (Exception e) {
                throw new MyCouponException("Repository Error: Failed to getAllCouponsByCompanyId",e);
            }
            break;
        }

        return company;
    }
}
