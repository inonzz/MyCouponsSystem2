package facadeImpl;

import facade.ClientFacade;

public class CustomerFacade extends ClientFacade {
    @Override
    public boolean login(String email, String password) {
        return false;
    }
}
