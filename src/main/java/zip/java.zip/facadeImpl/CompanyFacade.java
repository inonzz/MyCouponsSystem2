package facadeImpl;

import beans.Category;
import beans.Company;
import beans.Coupon;
import daoImpl.CompaniesDAODBImpl;
import daoImpl.CouponsDAODBImpl;
import daoImpl.CustomersDAODBImpl;
import exceptions.MyCouponException;
import facade.ClientFacade;
import java.util.ArrayList;

public class CompanyFacade extends ClientFacade {
    private int companyId;

    CompanyFacade(){

        this.companiesDAO = new CompaniesDAODBImpl();
        this.couponsDAO = new CouponsDAODBImpl();
        this.customersDAO = new CustomersDAODBImpl();

    }

    CompanyFacade(int companyId) {

        this();
        this.companyId = companyId;

    }

    //Login API ------------------------------------------------------------------------------------------
    @Override
    public boolean login(String email, String password) {
        //TODO how to add the user pass to the DB
        return false;
    }

    //Coupon API ------------------------------------------------------------------------------------------
    public void addCoupon(Coupon coupon) throws MyCouponException {
        addCouponValidation(coupon);
        couponsDAO.addCoupon(coupon);

    }

    public void updateCoupon(Coupon coupon) throws MyCouponException {
        updateCouponValidation(coupon);
        couponsDAO.addCoupon(coupon);
    }

    public void deleteCoupon(int couponId) throws MyCouponException {

            deleteCouponValidation(couponId);
            couponsDAO.deleteAllCouponsPurchasesById(couponId);
            couponsDAO.deleteCoupon(couponId);
        }

    public Company getCompanyDetails() throws MyCouponException {

        Company company =  companiesDAO.getOneCompany(companyId);
        if (company == null)
            throw new MyCouponException(String.format("Input Error: Company (id:%d) does not  Exist. get Company Details Failed\n",companyId));
        return company;
    }
    ArrayList<Coupon> getCompanyCoupons() throws MyCouponException {
        Company company =  companiesDAO.getOneCompany(companyId);
           if (company == null)
               throw new MyCouponException(String.format("Input Error: Company (id:%d) does not  Exist. get Company Coupons Failed\n",companyId));
        return company.getCoupons();
    }

    ArrayList<Coupon> getCompanyCoupons(Category category) throws MyCouponException {
        ArrayList<Coupon> coupons = getCompanyCoupons();
        ArrayList<Coupon> CategorisedCoupons = new  ArrayList<Coupon>();
        for (Coupon coupon: coupons)
            if (coupon.getCategory().getId() ==  category.getId())
                CategorisedCoupons.add(coupon);

        return CategorisedCoupons;
    }

    ArrayList<Coupon> getCompanyCoupons(double maxPrice) throws MyCouponException {
        ArrayList<Coupon> coupons = getCompanyCoupons();
        ArrayList<Coupon> MaxPricesCoupons = new  ArrayList<Coupon>();
        for (Coupon coupon: coupons)
            if (coupon.getPrice() <=  maxPrice)
                MaxPricesCoupons.add(coupon);

        return MaxPricesCoupons;
    }

    //PRIVATE METHODS------------------------------------------------------------------------------
    private void addCouponValidation(Coupon coupon) throws MyCouponException {
        if (couponsDAO.isCompanyCouponsTitleExist(companyId,coupon.getTitle())) {
            throw new MyCouponException(String.format("Input Error: Company (id:%d) Coupon title : (%s) Already Exist. Add Coupon Failed\n",
                    companyId, coupon.getTitle()));
        }
    }

    private void updateCouponValidation(Coupon coupon) throws MyCouponException {
        Coupon couponDB = couponsDAO.getOneCoupon(coupon.getId());
        if (couponDB == null)
            throw new MyCouponException(String.format("Input Error: Coupon  (id:%d) does not Exist. Add Coupon Failed\n",coupon.getId()));
        else if (couponDB.getCompanyId() != coupon.getCompanyId())
            throw new MyCouponException(String.format("Input Error: Coupon  (id:%d) Company Id (%d) can not be changed. Add Coupon Failed\n",coupon.getId(),coupon.getCompanyId()));
        }

    private void deleteCouponValidation(int  couponId) throws MyCouponException {
        Coupon coupon = couponsDAO.getOneCoupon(couponId);
        if (coupon == null)
            throw new MyCouponException(String.format("Input Error : Coupon (id:%d) Does not Exist!.Delete Coupon Failed\n", coupon.getId()));

    }

}
