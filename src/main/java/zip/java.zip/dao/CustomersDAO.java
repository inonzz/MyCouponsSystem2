package dao;
import beans.Customer;
import exceptions.MyCouponException;
import java.util.ArrayList;

public interface CustomersDAO {

    public boolean isCustomerExists(String email, String password) throws MyCouponException;

    public boolean isCustomerExistsByEmail(String email) throws MyCouponException;

    public boolean isCustomerExistsById(int  id) throws MyCouponException;

    public void addCustomer(Customer customer) throws MyCouponException;

    public void updateCustomer(Customer customer) throws MyCouponException;

    public void deleteCustomer(int customerId) throws MyCouponException;

    public ArrayList<Customer> getAllCustomers() throws MyCouponException;

    public Customer getOneCustomer(int customerId) throws MyCouponException;

    public ArrayList<Integer> getCustomerIdsByEmail(String email) throws MyCouponException;
}
