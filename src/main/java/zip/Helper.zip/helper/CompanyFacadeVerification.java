package helper;

import beans.Coupon;
import dao.CompaniesDAO;
import dao.CouponsDAO;
import dao.CustomersDAO;
import exceptions.MyCouponException;

public class CompanyFacadeVerification {
    private CompaniesDAO  companiesDAO;
    private CustomersDAO customersDAO;
    private CouponsDAO    couponsDAO;

    public CompanyFacadeVerification(CompaniesDAO companiesDAO, CouponsDAO couponsDAO, CustomersDAO customersDAO) {
        this.companiesDAO = companiesDAO;
        this.couponsDAO = couponsDAO;
        this.customersDAO = customersDAO;
    }

    //PRIVATE METHODS------------------------------------------------------------------------------
    public void addCouponValidation(Coupon coupon,int companyId) throws MyCouponException {
        if (couponsDAO.isCompanyCouponsTitleExist(companyId,coupon.getTitle())) {
            throw new MyCouponException(String.format("Input Error: Company (id:%d) Coupon title : (%s) Already Exist. Add Coupon Failed\n",
                    companyId, coupon.getTitle()));
        }
    }

    public void updateCouponValidation(Coupon coupon) throws MyCouponException {
        Coupon couponDB = couponsDAO.getOneCoupon(coupon.getId());
        if (couponDB == null)
            throw new MyCouponException(String.format("Input Error: Coupon  (id:%d) does not Exist. Add Coupon Failed\n",coupon.getId()));
        else if (couponDB.getCompanyId() != coupon.getCompanyId())
            throw new MyCouponException(String.format("Input Error: Coupon  (id:%d) Company Id (%d) can not be changed. Add Coupon Failed\n",coupon.getId(),coupon.getCompanyId()));
    }

    public void deleteCouponValidation(int  couponId) throws MyCouponException {
        Coupon coupon = couponsDAO.getOneCoupon(couponId);
        if (coupon == null)
            throw new MyCouponException(String.format("Input Error : Coupon (id:%d) Does not Exist!.Delete Coupon Failed\n", coupon.getId()));

    }
}
