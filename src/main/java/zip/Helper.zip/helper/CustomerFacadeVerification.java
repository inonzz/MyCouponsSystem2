package helper;

import dao.CompaniesDAO;
import dao.CouponsDAO;
import dao.CustomersDAO;

public class CustomerFacadeVerification {
    private CompaniesDAO  companiesDAO;
    private CustomersDAO customersDAO;
    private CouponsDAO    couponsDAO;

    public CustomerFacadeVerification(CompaniesDAO companiesDAO, CouponsDAO couponsDAO, CustomersDAO customersDAO) {
        this.companiesDAO = companiesDAO;
        this.couponsDAO = couponsDAO;
        this.customersDAO = customersDAO;
    }
}
