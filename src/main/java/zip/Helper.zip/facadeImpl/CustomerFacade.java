package facadeImpl;

import daoImpl.CompaniesDAODBImpl;
import daoImpl.CouponsDAODBImpl;
import daoImpl.CustomersDAODBImpl;
import facade.ClientFacade;
import helper.AdminFacadeVerification;
import helper.CustomerFacadeVerification;

public class CustomerFacade extends ClientFacade {
    private CustomerFacadeVerification customerFacadeVerification;

    public CustomerFacade() {

        this.companiesDAO = new CompaniesDAODBImpl();
        this.couponsDAO = new CouponsDAODBImpl();
        this.customersDAO = new CustomersDAODBImpl();
        this.customerFacadeVerification = new CustomerFacadeVerification(companiesDAO,couponsDAO,customersDAO);

    }
    @Override
    public boolean login(String email, String password) {
        return false;
    }
    
}
