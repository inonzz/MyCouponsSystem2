package daoImpl;

import beans.Company;
import beans.Coupon;
import beans.Customer;
import dao.CouponsDAO;
import dao.CustomersDAO;
import db.ConnectionPool;
import db.JDBCUtils;
import db.ResultsUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CustomersDAODBImpl implements CustomersDAO {

    //MEMBERS
    private ConnectionPool connectionPool;

    //QUERIES- customers
    private static final String QUERY_CUSTOMERS_INSERT = "INSERT INTO `coupons_system`.`customers` (`first_name`, `last_name`,`email`, `password`) VALUES (?, ?, ?, ?);\n";

    private static final String QUERY_CUSTOMERS_UPDATE = "UPDATE `coupons_system`.`customers` SET `first_name` = ?, `last_name` = ?,`email` = ?, `password` = ? WHERE (`id` = ?);\n";

    private static final String QUERY_CUSTOMERS_DELETE = "DELETE FROM `coupons_system`.`customers` WHERE (`id` = ?);";

    private static final String QUERY_CUSTOMERS_IS_EXIST_BY_EMAIL_AND_PASSWORD = "SELECT EXISTS(SELECT * FROM `coupons_system`.`customers` where email=? and password=?) as res";

    private static final String QUERY_ALL_CUSTOMERS_ID = "SELECT `id` FROM `coupons_system`.`customers`;";

    private static final String QUERY_CUSTOMERS_BY_ID = "SELECT * FROM `coupons_system`.`customers` where id=?";

    private static final String QUERY_CUSTOMERS_BY_COUPON_ID_DELETE = "DELETE FROM `coupons_system`.`customers` WHERE (`customer_id` = ? AND `coupon_id` = ?);\n";


    @Override
    public boolean isCustomerExists(String email, String password) throws Exception {
        boolean isExist = false;

        Map<Integer, Object> map = new HashMap<>();
        map.put(1, email);
        map.put(2, password);


        List<?> res = JDBCUtils.executeResults(QUERY_CUSTOMERS_IS_EXIST_BY_EMAIL_AND_PASSWORD, map);
        for (Object row : res) {
            isExist = ResultsUtils.fromHashMapToBoolean((HashMap<Integer, Object>) row);
            break;
        }

        return isExist;
    }

    @Override
    public void addCustomer(Customer customer) throws Exception {
        //add to customer table
        Map<Integer, Object> mapCustomer = new HashMap<>();
        mapCustomer.put(1, customer.getFirstName());
        mapCustomer.put(2, customer.getLastName());
        mapCustomer.put(3, customer.getEmail());
        mapCustomer.put(4, customer.getPassword());
        JDBCUtils.execute(QUERY_CUSTOMERS_INSERT, mapCustomer);

        //add customer coupons purchases
        ArrayList<Coupon> coupons = customer.getCoupons();
        CouponsDAO couponsDAU= new CouponsDAODBImpl();

        for (Coupon coupon : coupons) {
            couponsDAU.addCouponPurchase(customer.getId(), coupon.getId());
        }
    }

    @Override
    public void updateCustomer(Customer customer) throws Exception {

        Map<Integer, Object> mapCustomer = new HashMap<>();
        mapCustomer.put(1, customer.getFirstName());
        mapCustomer.put(2, customer.getLastName());
        mapCustomer.put(3, customer.getEmail());
        mapCustomer.put(4, customer.getPassword());
        mapCustomer.put(5, customer.getId());

        JDBCUtils.execute(QUERY_CUSTOMERS_UPDATE, mapCustomer);

        //update customer purchases
        ArrayList<Coupon> coupons = customer.getCoupons();
        CouponsDAO couponsDAU= new CouponsDAODBImpl();
        int customerId= 0;

        for (Coupon coupon : coupons) {
            customerId= customer.getId();
            if (!couponsDAU.isCouponPurchased(customerId)) {
                couponsDAU.addCouponPurchase(customer.getId(), coupon.getId());
            }
        }
    }

    @Override
    public void deleteCustomer(int customerId) throws Exception {

        Customer customer = getOneCustomer(customerId);
        ArrayList<Coupon> coupons= customer.getCoupons();
        CouponsDAO couponsDAO = new CouponsDAODBImpl();

        for (Coupon coupon : coupons){
            couponsDAO.deleteCouponPurchase(customerId, coupon.getId());
        }

        Map<Integer, Object> map = new HashMap<>();
        map.put(1, customerId);
        JDBCUtils.execute(QUERY_CUSTOMERS_DELETE, map);
    }

    @Override
    public ArrayList<Customer> getAllCustomer() throws Exception {
        ArrayList<Customer> customers = new ArrayList<>();

        List<?> res = JDBCUtils.executeResults(QUERY_ALL_CUSTOMERS_ID);

        int customerid = 0;
        for (Object row : res) {
            customerid  = (int) ((HashMap<?, ?>) row).get("id");
            customers.add(getOneCustomer(customerid));
        }
        return customers;
    }

    @Override
    public Customer getOneCustomer(int customerId) throws Exception {
        Customer customer = null;

        Map<Integer, Object> map = new HashMap<>();
        map.put(1, customerId);
        List<?> resCustomerTable = JDBCUtils.executeResults(QUERY_CUSTOMERS_BY_ID, map);


        CouponsDAO couponsDAO = new CouponsDAODBImpl();

        for (Object rowCustomerTable : resCustomerTable) {
            customer = ResultsUtils.fromHashMapToCustomer((HashMap<Integer, Object>) rowCustomerTable,
                    couponsDAO.getAllCouponsByCustomerId(customerId));

        }
        return customer;
    }

}
