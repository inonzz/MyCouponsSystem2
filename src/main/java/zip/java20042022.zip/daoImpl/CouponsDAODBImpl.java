package daoImpl;

import beans.Category;
import beans.Coupon;
import dao.CategoriesDAO;
import dao.CouponsDAO;
import dao.CustomersDAO;
import db.ConnectionPool;
import db.JDBCUtils;
import db.ResultsUtils;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CouponsDAODBImpl implements CouponsDAO {
    //MEMBERS
    private ConnectionPool connectionPool;
    //QUERIES



    private static final String QUERY_COUPONS_INSERT    = "INSERT INTO `coupons_system`.`coupons` \n"+
        "(`company_id`, `category_id`, `title`, \n"+
        "`description`, `start_date`, `end_date`, \n"+
        "`amount`, `price`, `image`) \n"+
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);";

    private static final String QUERY_COUPONS_UPDATE    = "UPDATE `coupons_system`.`coupons` \n"+
            "SET `Coupon_id` = ?, `category_id` = ?, `title` = ?, \n"+
            "`description` = ?, `start_date` = ?, `end_date` = ? \n"+
            "`amount` = ?, `price` = ?, `image` = ?\n"+
            "WHERE (`id` = ?);\n";

    private static final String QUERY_COUPONS_DELETE    = "DELETE FROM `coupons_system`.`coupons` \n"+
            "WHERE (`id` = ?);";

    private static final String QUERY_ALL_COUPONS     = "SELECT * FROM `coupons_system`.`coupons`;";

    private static final String QUERY_COUPONS_BY_ID     = "SELECT * FROM `coupons_system`.`coupons` \n"+
            " where id = ?";

    private static final String QUERY_COUPONS_ID_BY_COMPANY_ID     = "SELECT id FROM `coupons_system`.`coupons` \n"+
            " where company_id = ? ";


    private static final String QUERY_CUSTOMERS_VS_COUPONS_INSERT    = "INSERT INTO `coupons_system`.`customers_vs_coupons` \n"+
            "(`customer_id`, `coupon__id`VALUES (?, ?);";

    private static final String QUERY_CUSTOMERS_VS_COUPONS_DELETE    = "DELETE FROM `coupons_system`.`customers_vs_coupons` \n"+
            "WHERE (`customer_id` = ? AND coupon__id = ?);";

    private static final String QUERY_CUSTOMERS_VS_COUPONS_IS_EXIST_COUPON_ID    = "SELECT EXISTS(SELECT * FROM `coupons_system`.`customers_vs_coupons` \n"+
            "where coupon_id = ? ) as res";

    private static final String QUERY_CUSTOMERS_VS_COUPONS_BY_COUPON_ID    = "select `customer_id` FROM `coupons_system`.`customers_vs_coupons` \n"+
            "where coupon_id = ?;";
    private static final String  QUERY_CUSTOMERS_VS_COUPONS_BY_CUSTOMER_ID = "select `coupon_id` FROM `coupons_system`.`customers_vs_coupons` \n"+
            "where customer_id = ?;";

    @Override
    public void addCoupon(Coupon coupon) throws Exception{

        Map<Integer, Object> map = new HashMap<>();
        map.put(1, coupon.getCompanyId());
        map.put(2, coupon.getCategory().getId());
        map.put(3, coupon.getTitle());
        map.put(4, coupon.getDescription());
        map.put(5, coupon.getStartDate());
        map.put(6, coupon.getEndDate());
        map.put(7, coupon.getAmount());
        map.put(8, coupon.getPrice());
        map.put(9, coupon.getImage());

        JDBCUtils.execute(QUERY_COUPONS_INSERT, map);


    }




    @Override
    public void updateCoupon(Coupon coupon) throws Exception{

        Map<Integer, Object> map = new HashMap<>();
        map.put(1, coupon.getCompanyId());
        map.put(2, coupon.getCategory().getId());
        map.put(3, coupon.getTitle());
        map.put(4, coupon.getDescription());
        map.put(5, coupon.getStartDate());
        map.put(6, coupon.getEndDate());
        map.put(7, coupon.getAmount());
        map.put(8, coupon.getPrice());
        map.put(9, coupon.getImage());
        map.put(10, coupon.getId());
        JDBCUtils.execute(QUERY_COUPONS_UPDATE, map);
    }

    @Override
    public void deleteCoupon(int couponId) throws Exception{
        //Delete coupon and couponId from : coupons  and if exist , from  customersVsCoupons
        int customerId = 0 ;
        //1. check if the customerId exist in customersVsCoupons and
        List<?> res = getAllCustomersPurchaseByCouponId(couponId);
        for (Object row : res) {
            customerId = ResultsUtils.fromHashMapToInt((HashMap<Integer, Object>) row);
            //delete from customersVsCoupons
            deleteCouponPurchase(customerId, couponId);
        }
        //delete Coupon
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, couponId);
        JDBCUtils.execute(QUERY_COUPONS_DELETE, map);

    }

    @Override
    public ArrayList<Coupon> getAllCoupons() throws Exception {
        ArrayList<Coupon> coupons = new ArrayList<>();

        List<?> res = JDBCUtils.executeResults(QUERY_ALL_COUPONS);
        for (Object row : res) {
            coupons.add( ResultsUtils.fromHashMapToCoupon((HashMap<Integer, Object>) row));
        }
        return coupons;
    }


    //NEW
    public ArrayList<Integer> getAllCustomersPurchaseByCouponId(int couponId) throws Exception {

        Map<Integer, Object> map = new HashMap<>();
        map.put(1, couponId);

        List<?> res = JDBCUtils.executeResults(QUERY_CUSTOMERS_VS_COUPONS_BY_COUPON_ID,map);
        ArrayList<Integer> customerIds = new ArrayList<>();

        for (Object row : res) {
            customerIds.add( ResultsUtils.fromHashMapToInt((HashMap<Integer, Object>) row));
        }
        return customerIds;
    }
    @Override
    public Coupon getOneCoupon(int couponId) throws Exception{
        Coupon coupon = null;

        Map<Integer, Object> map = new HashMap<>();
        map.put(1, couponId);
        List<?> res = JDBCUtils.executeResults(QUERY_COUPONS_BY_ID, map);
        for (Object row : res) {
            coupon = (ResultsUtils.fromHashMapToCoupon((HashMap<Integer, Object>) row));
            break;
        }
        return coupon;
    }


    @Override
    public void addCouponPurchase(int customerId, int couponId) throws Exception{
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, customerId);
        map.put(2, couponId);
        JDBCUtils.execute(QUERY_CUSTOMERS_VS_COUPONS_INSERT, map);
    }

    @Override
    public void deleteCouponPurchase(int customerId, int couponId) throws Exception{
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, customerId);
        map.put(2, couponId);
        JDBCUtils.execute(QUERY_CUSTOMERS_VS_COUPONS_DELETE, map);
    }

    @Override
    //NEW
    public boolean isCouponPurchased(int couponId) throws Exception {
        boolean isExist = false;

        Map<Integer, Object> map = new HashMap<>();
        map.put(1, couponId);


        List<?> res = JDBCUtils.executeResults(QUERY_CUSTOMERS_VS_COUPONS_IS_EXIST_COUPON_ID, map);
        for (Object row : res) {
            isExist = ResultsUtils.fromHashMapToBoolean((HashMap<Integer, Object>) row);
            break;
        }

        return isExist;

    }

    @Override
    public ArrayList<Coupon> getAllCouponsByCustomerId(int customerId) throws Exception {

        Map<Integer, Object> map = new HashMap<>();
        map.put(1, customerId);

        List<?> res = JDBCUtils.executeResults(QUERY_CUSTOMERS_VS_COUPONS_BY_CUSTOMER_ID,map);
        ArrayList<Coupon> coupons = new ArrayList<>();
        int couponId = 0;

        for (Object row : res) {
            couponId = ResultsUtils.fromHashMapToInt((HashMap<Integer, Object>) row);
            coupons.add(getOneCoupon(couponId));
         }
        return coupons;
    }

    public ArrayList<Coupon> getAllCouponsByCompanyId(int companyId) throws Exception{

        Map<Integer, Object> map = new HashMap<>();
        map.put(1, companyId);

        List<?> res = JDBCUtils.executeResults(QUERY_COUPONS_ID_BY_COMPANY_ID,map);

        int couponId = -1;
        ArrayList<Coupon> coupons = new ArrayList<>();
        for (Object row : res) {
            couponId = ResultsUtils.fromHashMapToCouponId((HashMap<Integer, Object>) row);
            coupons.add(getOneCoupon(couponId));
        }
        return coupons;

    }

}
