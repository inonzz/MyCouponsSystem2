package dao;

import beans.Category;

import java.util.ArrayList;

public interface CategoriesDAO {

    public void addCategory(Category category) throws Exception;

    public ArrayList<Category> getAllCategories() throws Exception;

  //  public Category getOneCategory(int categoryId) throws Exception;

    public boolean IsCategoryExist(int categoryId) throws Exception;
 }
