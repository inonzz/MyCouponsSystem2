package dao;

import beans.Coupon;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public interface CouponsDAO {

    public void addCoupon(Coupon coupon) throws Exception;

    public void updateCoupon(Coupon coupon) throws Exception;

    public void deleteCoupon(int couponId) throws Exception;

    public ArrayList<Coupon> getAllCoupons() throws Exception;

    public Coupon getOneCoupon(int CouponId) throws Exception;

    public void addCouponPurchase(int CustomerId, int CouponId) throws Exception;

    public void deleteCouponPurchase(int CustomerId, int CouponId) throws Exception;

    public boolean isCouponPurchased(int couponId) throws Exception;

    ArrayList<Coupon> getAllCouponsByCustomerId(int customerId)throws Exception;

    ArrayList<Coupon> getAllCouponsByCompanyId(int companyId) throws Exception;;
}
