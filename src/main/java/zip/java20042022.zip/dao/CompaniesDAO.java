package dao;

import beans.Company;

import java.sql.SQLException;
import java.util.ArrayList;

public interface CompaniesDAO {

    public boolean isCompanyExists(String email, String password) throws Exception;

    public void addCompany(Company company) throws Exception;

    public void updateCompany(Company company) throws SQLException, InterruptedException, Exception;

    public void deleteCompany(int companyId) throws Exception;

    public ArrayList<Company> getAllCompanies() throws Exception;

    public Company getOneCompany(int companyId) throws Exception;
}
