package dao;

import beans.Company;
import beans.Customer;

import java.util.ArrayList;

public interface CustomersDAO {

    public boolean isCustomerExists(String email, String password) throws Exception;

    public void addCustomer(Customer customer) throws Exception;

    public void updateCustomer(Customer customer) throws Exception;

    public void deleteCustomer(int customerId) throws Exception;

    public ArrayList<Customer> getAllCustomer() throws Exception;

    public Customer getOneCustomer(int customerId) throws Exception;


}
