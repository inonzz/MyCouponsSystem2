package apps;

import beans.Category;
import beans.Company;
import beans.Coupon;
import dao.CategoriesDAO;
import dao.CompaniesDAO;
import dao.CouponsDAO;
import daoImpl.CategoriesDAODBImpl;
import daoImpl.CompaniesDAODBImpl;
import daoImpl.CouponsDAODBImpl;
import db.ConnectionPool;
import db.DatabaseManager;

import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Test {
    private static final int MAX_COMPANIES = 3;

    public static void main(String[] args) {

        System.out.println("======start building the DB======");

        try {
            DatabaseManager.databaseStrategy();
            System.out.println("======Test init Categories=======");
            InitCategories();
            System.out.println("======Test init Companies DAO======");
            testInitCompaniesDAO();
            System.out.println("=======Test init Coupons DAO=======");
            testInitCouponsDAO();
            System.out.println("======Test init Customer DAO======");
            testInitCustomersDAO();

            System.out.println("======Test bind Coupons to Company======");
            testCustomersDAO();
            System.out.println("======close resources======");

            // add here check on tables


            ConnectionPool.getInstance().closeAllConnections();

        } catch (Exception e) {
            System.out.println("Exception");
            e.printStackTrace();
        }


        System.out.println("END");

    }
    private static void InitCategories() throws Exception{

        CategoriesDAO categoriesDAO = new CategoriesDAODBImpl();
        categoriesDAO.addCategory(Category.FOOD);
        categoriesDAO.addCategory(Category.ELECTRICITY);
        categoriesDAO.addCategory(Category.RESTAURANT);
        categoriesDAO.addCategory(Category.VACATION);
        categoriesDAO.getAllCategories().forEach(System.out::println);
      }
    private static void testInitCustomersDAO() throws Exception{

    }

    public static void testInitCompaniesDAO() throws Exception {



        //init companies beans
        List<Coupon> couponListCompany1 = new ArrayList<>();
        List<Coupon> couponListCompany2 = new ArrayList<>();
        List<Coupon> couponListCompany3 = new ArrayList<>();

        Company company1 = new Company("Company1","Company1@gmail.com","1234", (ArrayList<Coupon>) couponListCompany1);
        Company company2 = new Company("Company2","company2@gmail.com","5678", (ArrayList<Coupon>) couponListCompany2);
        Company company3 = new Company("Company3","company3@gmail.com","9012", (ArrayList<Coupon>) couponListCompany3);
        System.out.println("Company1 bean" + company1);
        System.out.println("Company2 bean" + company2);
        System.out.println("Company3 bean" + company3);

         //add Companies to DB
        CompaniesDAO companiesDAO = new CompaniesDAODBImpl();
        companiesDAO.addCompany(company1);
        companiesDAO.addCompany(company2);
        companiesDAO.addCompany(company3);
        System.out.println("print Companies DB");
        companiesDAO.getAllCompanies().forEach(System.out::println);
    }

    public static void testInitCouponsDAO() throws Exception {
        //get Company ID
        CompaniesDAO companiesDAO = new CompaniesDAODBImpl();
        ArrayList<Company> allCompanies  = companiesDAO.getAllCompanies();
        if (allCompanies.size() < MAX_COMPANIES) {
            throw new Exception();
        }


        //init coupons  plus link to company

        Coupon coupon1Comp1 = new Coupon(allCompanies.get(0).getId(), Category.FOOD,"PizzaDalal","Good Pizza place",Date.valueOf("2022-04-25"),Date.valueOf("2022-04-26"),10,20,"*****" );
        Coupon coupon2Comp1 = new Coupon(allCompanies.get(0).getId(), Category.VACATION,"ScubaDalal","Scuba Dive",Date.valueOf("2022-04-25"),Date.valueOf("2022-04-26"),10,20,"*****" );

        Coupon coupon1Comp2 = new Coupon(allCompanies.get(1).getId(), Category.ELECTRICITY,"CompDalal","computer place",Date.valueOf("2022-04-25"),Date.valueOf("2022-04-26"),10,20,"****" );
        Coupon coupon2Comp2 = new Coupon(allCompanies.get(1).getId(), Category.RESTAURANT,"FalafelDalal","Falafel Fast food",Date.valueOf("2022-04-25"),Date.valueOf("2022-04-26"),10,20,"****" );

        Coupon coupon1Comp3 = new Coupon(allCompanies.get(2).getId(), Category.ELECTRICITY,"Salon  Dalal","Electricity  place",Date.valueOf("2022-04-25"),Date.valueOf("2022-04-26"),10,20,"***" );
        Coupon coupon2Comp3 = new Coupon(allCompanies.get(2).getId(), Category.VACATION," HOTEL Dalal","Hotel Place",Date.valueOf("2022-04-25"),Date.valueOf("2022-04-26"),10,20,"***" );

        System.out.println("print Coupons beans total 6");
        System.out.println("coupon1Comp1 bean" + coupon1Comp1);
        System.out.println("coupon2Comp1 bean" + coupon2Comp1);

        System.out.println("coupon1Comp2 bean" + coupon1Comp2);
        System.out.println("coupon2Comp2 bean" + coupon2Comp2);

        System.out.println("coupon1Comp3 bean" + coupon1Comp3);
        System.out.println("coupon2Comp3 bean" + coupon2Comp3);

        //add coupons to DB
        CouponsDAO couponsDAO = new CouponsDAODBImpl();
        couponsDAO.addCoupon(coupon1Comp1);
        couponsDAO.addCoupon(coupon2Comp1);

        couponsDAO.addCoupon(coupon1Comp2);
        couponsDAO.addCoupon(coupon2Comp2);

        couponsDAO.addCoupon(coupon1Comp3);
        couponsDAO.addCoupon(coupon2Comp3);

        System.out.println("print Coupons DB");
        couponsDAO.getAllCoupons().forEach(System.out::println);

       //update coupons list to company
        System.out.println("print Companies DB after binding coupons");
        companiesDAO.getAllCompanies().forEach(System.out::println);



    }

    public static void testCustomersDAO() {



    }
}
