package daoImpl;

import beans.Category;
import beans.Coupon;
import dao.CategoriesDAO;
import db.JDBCUtils;
import db.ResultsUtils;
import exceptions.MyCouponException;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CategoriesDAODBImpl implements CategoriesDAO {
    private static final String QUERY_CATEGORIES_INSERT    = "INSERT INTO `coupons_system`.`categories` \n"+
            "(`name`) \n"+
            "VALUES (?);";

    private static final String QUERY_CATEGORIES_IS_EXIST_BY_ID = "SELECT EXISTS(SELECT * FROM `coupons_system`.`categories` where id=?) as res";

    private static final String QUERY_CATEGORIES_BY_ID = "SELECT * FROM `coupons_system`.`categories` where id=?";

    private static final String QUERY_CATEGORIES = "SELECT * FROM `coupons_system`.`categories`";


    @Override
    public void addCategory(Category category) throws SQLException, InterruptedException {
        Map<Integer, Object> map = new HashMap<>();
        map.put(1, category.name());

        JDBCUtils.execute(QUERY_CATEGORIES_INSERT, map);
    }

    @Override
    //for test purposes
    public ArrayList<Category> getAllCategories() throws SQLException, InterruptedException {
        ArrayList<Category> categories = new ArrayList<>();

        List<?> res = JDBCUtils.executeResults(QUERY_CATEGORIES);
        for (Object row : res) {
            categories.add( ResultsUtils.fromHashMapToCategory((HashMap<Integer, Object>) row));
        }
        return categories;
    }

    //
//    @Override
//    public Category getOneCategory(int categoryId) throws Exception {
//        Category category = null;
//
//        Map<Integer, Object> map = new HashMap<>();
//        map.put(1, categoryId);
//        List<?> res = JDBCUtils.executeResults(QUERY_CATEGORIES_BY_ID, map);
//        for (Object row : res) {
//            category = (ResultsUtils.fromHashMapToCaregory((HashMap<Integer, Object>) row));
//            break;
//        }
//        return category;
//    }

    @Override
    public boolean IsCategoryExist(int categoryId) throws SQLException, InterruptedException  {

        boolean isExist = false;

        Map<Integer, Object> map = new HashMap<>();
        map.put(1, categoryId);

        List<?> res = JDBCUtils.executeResults(QUERY_CATEGORIES_BY_ID, map);
        for (Object row : res) {
            isExist = ResultsUtils.fromHashMapToBoolean((HashMap<Integer, Object>) row);
            break;
        }

        return isExist;
    }
}
