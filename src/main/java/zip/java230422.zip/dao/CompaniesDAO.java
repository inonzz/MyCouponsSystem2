package dao;

import beans.Company;
import exceptions.MyCouponException;

import java.sql.SQLException;
import java.util.ArrayList;

public interface CompaniesDAO {

    public boolean isCompanyExists(String email, String password) throws SQLException, InterruptedException;

    public boolean isCompanyExistsByNameOrEmail(String name, String email) throws SQLException, InterruptedException;

    public boolean isCompanyExistsByNameAndId(String name, int id) throws SQLException, InterruptedException;

    public void addCompany(Company company) throws SQLException, InterruptedException;

    public void updateCompany(Company company) throws SQLException, InterruptedException;

    public void deleteCompany(int companyId) throws SQLException, InterruptedException;

    public ArrayList<Company> getAllCompanies() throws SQLException, InterruptedException;

    public Company getOneCompany(int companyId) throws SQLException, InterruptedException;
}
