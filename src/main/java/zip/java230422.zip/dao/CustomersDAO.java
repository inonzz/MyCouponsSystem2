package dao;

import beans.Company;
import beans.Customer;
import exceptions.MyCouponException;

import java.sql.SQLException;
import java.util.ArrayList;

public interface CustomersDAO {

    public boolean isCustomerExists(String email, String password) throws SQLException, InterruptedException;

    public boolean isCustomerExistsByEmail(String email) throws SQLException, InterruptedException;

    public boolean isCustomerExistsById(int  id) throws SQLException, InterruptedException;

    public void addCustomer(Customer customer) throws SQLException, InterruptedException;

    public void updateCustomer(Customer customer) throws SQLException, InterruptedException;

    public void deleteCustomer(int customerId) throws SQLException, InterruptedException;

    public ArrayList<Customer> getAllCustomers() throws SQLException, InterruptedException;

    public Customer getOneCustomer(int customerId) throws SQLException, InterruptedException;

    public ArrayList<Integer> getCustomerIdsByEmail(String email) throws SQLException, InterruptedException;
}
