package dao;

import beans.Coupon;
import beans.Customer;
import exceptions.MyCouponException;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public interface CouponsDAO {

    public void addCoupon(Coupon coupon) throws SQLException, InterruptedException;

    public void updateCoupon(Coupon coupon) throws SQLException, InterruptedException;

    public void deleteCoupon(int couponId) throws SQLException, InterruptedException;

    public ArrayList<Coupon> getAllCoupons() throws SQLException, InterruptedException;

    public Coupon getOneCoupon(int CouponId) throws SQLException, InterruptedException;

    public void addCouponPurchase(int CustomerId, int CouponId) throws SQLException, InterruptedException;

    public void deleteCouponPurchase(int CustomerId, int CouponId) throws SQLException, InterruptedException;

//Additional  Methods
    public boolean isCouponPurchased(int couponId) throws SQLException, InterruptedException;

    public ArrayList<Coupon> getAllCouponsByCompanyId(int companyId) throws SQLException, InterruptedException;

    List<?> getAllCouponsByCustomerId(int customerId) throws SQLException, InterruptedException;

    public void deleteAllCouponsPurchasesById(int coupon_id) throws SQLException, InterruptedException;

    public boolean isCompanyCouponsTitleExist(int companyId, String couponTitle) throws SQLException, InterruptedException;
}
