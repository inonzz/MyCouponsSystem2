package dao;

import beans.Category;
import exceptions.MyCouponException;

import java.sql.SQLException;
import java.util.ArrayList;

public interface CategoriesDAO {

    public void addCategory(Category category) throws SQLException, InterruptedException;

    public ArrayList<Category> getAllCategories() throws SQLException, InterruptedException;

  //  public Category getOneCategory(int categoryId) throws MyCouponException;

    public boolean IsCategoryExist(int categoryId) throws SQLException, InterruptedException;
 }
