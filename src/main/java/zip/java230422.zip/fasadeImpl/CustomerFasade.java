package fasadeImpl;

import fasade.ClientFasade;

public class CustomerFasade extends ClientFasade {
    @Override
    public boolean login(String email, String password) {
        return false;
    }
}
