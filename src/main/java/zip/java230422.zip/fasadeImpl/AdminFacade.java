package fasadeImpl;

import beans.Company;
import beans.Coupon;
import beans.Customer;
import daoImpl.CompaniesDAODBImpl;
import daoImpl.CouponsDAODBImpl;
import daoImpl.CustomersDAODBImpl;
import exceptions.MyCouponException;
import fasade.ClientFasade;

import java.sql.SQLException;
import java.util.ArrayList;

public class AdminFacade extends ClientFasade {
    private static final String EMAIL = "admin@admin.com";
    private static final String PASSWORD = "admin";


    public AdminFacade() {

        this.companiesDAO = new CompaniesDAODBImpl();
        this.couponsDAO = new CouponsDAODBImpl();
        this.customersDAO = new CustomersDAODBImpl();

    }
    //Login API ------------------------------------------------------------------------------------------

    @Override
    public boolean login(String email, String password) {
        return (EMAIL.equals(email) && (PASSWORD.equals(password)));
    }


    //COMPANY API ------------------------------------------------------------------------------------------
    public void addCompany(Company company) throws SQLException, InterruptedException, MyCouponException {
        addCompanyValidation(company);
        companiesDAO.addCompany(company);
    }

    public void updateCompany(Company company) throws SQLException, InterruptedException, MyCouponException {
        updateCompanyValidation(company);
        companiesDAO.updateCompany(company);

    }

    public void deleteCompany(int companyId) throws SQLException, InterruptedException, MyCouponException {
        Company company = companiesDAO.getOneCompany(companyId);

        if (company == null)
            throw new MyCouponException(String.format("Error : Company (id:%d) Does not Exist!\n", company.getId()));

        ArrayList<Coupon> coupons = company.getCoupons();
        for (Coupon coupon : coupons) {
            couponsDAO.deleteCoupon(companyId);
            couponsDAO.deleteAllCouponsPurchasesById(coupon.getId());
        }
        companiesDAO.deleteCompany(companyId);
    }

    public ArrayList<Company> getAllCompanies() throws SQLException, InterruptedException {
        return companiesDAO.getAllCompanies();
    }

    public Company getOneCompany(int companyId) throws SQLException, InterruptedException {
        return companiesDAO.getOneCompany(companyId);
    }

    //CUSTOMER API ------------------------------------------------------------------------------------------
    public void addCustomer(Customer customer) throws SQLException, InterruptedException, MyCouponException {

        addCustomerValidation(customer);
        customersDAO.addCustomer(customer);
    }

    public void updateCustomer(Customer customer) throws SQLException, InterruptedException, MyCouponException {

        updateCustomerValidation(customer);
        customersDAO.updateCustomer(customer);
    }

    public void deleteCustomer(int customerId) throws SQLException, InterruptedException, MyCouponException {
        Customer customer = customersDAO.getOneCustomer(customerId);

        if (customer == null)
            throw new MyCouponException(String.format("Input Error : Company (id:%d) Does not Exist!. Delete Customer Failed\n", customer.getId()));

        ArrayList<Coupon> coupons = customer.getCoupons();
        for (Coupon coupon : coupons) {
            couponsDAO.deleteCouponPurchase(customerId, coupon.getId());
        }
        customersDAO.deleteCustomer(customerId);
    }

    public ArrayList<Customer> getAllCustomers() throws SQLException, InterruptedException {
        return customersDAO.getAllCustomers();
    }

    public Customer getOneCustomer(int customerId) throws SQLException, InterruptedException {
        return customersDAO.getOneCustomer(customerId);
    }

    //PRIVATE METHODS------------------------------------------------------------------------------
    private void updateCompanyValidation(Company company) throws MyCouponException, SQLException, InterruptedException {

        Company companyDB = companiesDAO.getOneCompany(company.getId());
        if (companyDB == null)
            throw new MyCouponException(String.format("Input Error: Company  (id:%d) does not Exist. update Company Failed\n", company.getId()));
        else if (companyDB.getName() != company.getName())
            throw new MyCouponException(String.format("Input Error: Company  (id:%d) new Company Name (%s) can not be changed from (%s). update Company Failed\n",
                    company.getId(), company.getName(), companyDB.getName()));
        else if (companyDB.getId() != company.getId())
            throw new MyCouponException(String.format("Input Error: Company  (id:%d) can not be changed to (%s). update Company Failed\n",
                    companyDB.getId(), company.getId()));
    }


    private void addCompanyValidation(Company company) throws SQLException, InterruptedException, MyCouponException {
        //check if not similar Name,Email exist
        Company companyDB = companiesDAO.getOneCompany(company.getId());
        if ((companyDB != null) && (companyDB.getName() == company.getName())) {
            throw new MyCouponException(
                    String.format("Input Error: Company Name (%s) already exist. Add Company Failed\n",
                            company.getName()));
        } else if ((companyDB != null) && (companyDB.getEmail() == company.getEmail())) {
            throw new MyCouponException(
                    String.format("Input Error: Company Email (%s) already exist. Add Company Failed\n",
                            company.getEmail()));
        }

    }

    private void addCustomerValidation(Customer customer) throws SQLException, InterruptedException, MyCouponException {
        //can not add customer with similar email
        Customer customerDB = customersDAO.getOneCustomer(customer.getId());
        if ((customerDB != null) && (customerDB.getEmail() == customer.getEmail())) {
            throw new MyCouponException(
                    String.format("Input Error: Customer email (%s) already exist. Add Customer Failed\n",
                            customerDB.getEmail()));
        }
    }

    private void updateCustomerValidation(Customer customer) throws MyCouponException, SQLException, InterruptedException {
        //can not update customer id
        Customer customerDB = customersDAO.getOneCustomer(customer.getId());
        if (customerDB == null)
            throw new MyCouponException(
                    String.format("Input Error: Customer is (%d) does not  exist. Update Customer Failed\n",
                            customerDB.getId()));
    }

}
