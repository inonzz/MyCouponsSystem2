package exceptions;

import java.sql.SQLException;

public class MyCouponException extends Exception {
    public MyCouponException(String s)
    {
        // Call constructor of parent Exception
        super(s);
    }
}
